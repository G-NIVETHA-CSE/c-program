#include<stdio.h>
int main()
{
   char a[10];
   printf("enter the string\n");
   scanf("%s",a);
   char *p;
   p=a;
   int i;
   for(i=0;a[i]!='\0';i++);
   printf("the length of string %d",i);
   return 0;
}
