#include<stdio.h>
#include<stdlib.h>
struct node 
{
    int data;
    struct node *next;
};
struct node *head=NULL,*new,*temp;
void create(struct node **head,int t)
{
    new=(struct node*)malloc(sizeof(struct node));
    new->data=t;
    new->next=*head;
    *head=new;
}


void print()
{
    temp=head;
    while(temp!=NULL)
    {
        printf(" %d",temp->data);
       // printf("=%u\n",temp->next);
        temp=temp->next;
    }
    // printf("=%u\n",head);
    printf("\n");
}

int detectloop(struct node **list)   

{  
   struct node *S = *list, *F=*list;  
   while(S && F && F->next)   
    {  
        S=S->next;  
      F=F->next->next;  
            if(F==S)  
            {  
                printf("%d",S->data);
               printf("loop exists");  
              return 1;  
            } 
    }
    printf("not exists");
}
int main()
{
    create(&head,3);
    create(&head,5);
    create(&head,2);
    create(&head,1);
    print();
    new->data=9;
    new->next=head;
    detectloop(&head);

}
