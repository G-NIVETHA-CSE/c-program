#include<stdio.h>
#include <stdlib.h>
typedef struct {
		unsigned int dd;
		unsigned int mm;
		unsigned int yy;
		}date;
		
void main()
{
	date *d1,*d2,*d;
	d=(date *)malloc(sizeof(date));
	d1=(date *)malloc(sizeof(date));
	d2=(date *)malloc(sizeof(date));
	printf("enter the start date\n");
	scanf("%d/%d/%d",&d1->dd,&d1->mm,&d1->yy);
	printf("enter the end date\n");
	scanf("%d/%d/%d",&d2->dd,&d2->mm,&d2->yy);
	if(d2->dd<d1->dd)
	{
		if(d2->mm==3)
		{
			if(d2->yy%100!=0 && d2->yy%4==0  ||  d2->yy%400==0) 
				d2->dd=d2->dd+29;
			else
				d2->dd=d2->dd+28;
		}
		else if(d2->mm==5 || d2->mm==7 || d2->mm==10 || d2->mm==12)
			d2->dd=d2->dd+30;
		else
			d2->dd=d2->dd+31;
		d2->mm=d2->mm-1;
	}
	if(d2->mm<d1->mm)
	{
		d2->yy=d2->yy-1;
		d2->mm=d2->mm+12;
	}
	d->yy=d2->yy-d1->yy;
	d->mm=d2->mm-d1->mm;
	d->dd=d2->dd-d1->dd;
	printf("Difference of the two dates is : ");
	printf("%d years %d months %d days\n",d->yy,d->mm,d->dd);
	
}	
