// Online C compiler to run C program online
#include <stdio.h>
#include <stdlib.h>
int main() {
    int i,j,n,k=1;
    printf("enter the range");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(j=-i;j<=i;j++)
        {
            if(j==0)
            {
            
                printf("%d",k);
            }
            else if(j<i)
            {
            printf("%d",k-abs(j));
            }
           
            else
            {
                printf("%d",k-abs(j));
            }
        }
        k=k+2;
        printf("\n");
    }

    return 0;
}
