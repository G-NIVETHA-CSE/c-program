#include<stdio.h>
#include<stdlib.h>

char *dup(char *s)
{
	int i;
	char *c=(char*)malloc(sizeof(*s));
	for(i=0;s[i]!='\0';i++)
	{
		*(c+i)=*(s+i);
	}
	 *(c+i)='\0';
	return c;
}
int main()
{
	char a[10];
	printf("enter the string");
	scanf("%s",a);
	char *p;
	p=dup(a);
	printf("the copy string %s",p);
}
