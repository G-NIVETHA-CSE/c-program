#include<stdio.h>
void f(int *a,int *b)
{
	*a=5;
	*b=10;
}
int main()
{
	int a,b;
	f(&a,&b);
	printf("a=%d\nb=%d\n",a,b);
	return 0;
}
