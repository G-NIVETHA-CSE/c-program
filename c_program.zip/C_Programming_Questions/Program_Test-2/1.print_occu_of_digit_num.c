#include<stdio.h>
int main()
{
 int num,part;
 printf("enter the number\n");
 scanf("%d",&num);
 printf("enter the particular digit");
 scanf("%d",&part);
 int b,count=0;
 while(num!=0)
 {
  b=num%10;
  num=num/10;
  if(b==part)
  {
	  count++;
  }
 }
 printf("the particular digit count is  %d",count);
}

