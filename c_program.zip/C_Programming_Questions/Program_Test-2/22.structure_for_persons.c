// Online C compiler to run C program online
#include <stdio.h>
 int n=0;
struct person
{   char name[20];
    int age;
};
void sort(struct person *p, int n) {
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if ((p + i)->age > (p + j)->age) {
                struct person temp = *(p + i);
                *(p + i) = *(p + j);
                *(p + j) = temp;
            }
        }
    }
}
/*
void sort1(struct person *p)
{
    
    int i,j;
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(*(p+i)->age > *(p+j)->age)
            {
                struct person temp=*(p+i);
                *(p+i)=*(p+j);
                *(p+j)=temp;
            }
        }
    }
}
*/
int main()
{
 struct person a[5];
 struct person *ptr;
 ptr=a;
 int i;
 printf("how many persons\n");
 scanf("%d",&n);
 printf("enter the name and age \n");
 for(i=0;i<n;i++)
 {
     scanf("%s",&a[i].name);
     scanf("%d",&a[i].age);
 }
 
  for(i=0;i<n;i++)
 {
     printf("name:%s\n age:%d\n",(ptr+i)->name,a[i].age);
 }
 sort(ptr,n);
 printf("After sorting");
for(i=0;i<n;i++)
 {
     printf("name:%s\n age:%d\n",a[i].name,a[i].age);
 }
 
    return 0;
}
