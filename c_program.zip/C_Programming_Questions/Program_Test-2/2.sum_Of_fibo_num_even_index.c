#include<stdio.h>
int main()
{
 int a=0,b=1;
 int range,i,c,sum=0;
 printf("enter the fibonacci series range");
 scanf("%d",&range);
 for(i=1;i<=range-1;i++)
 {
	 c=a+b;
	 a=b;
	 b=c;
  if((i%2==0))
  {
	  sum+=c;
  }
 }
 printf("the sum of even of fibonacci series %d",sum);
}
