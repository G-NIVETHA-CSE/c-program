#include<stdio.h>
#include<stdlib.h>
struct node 
{
    int data;
    struct node *next;
};
struct node *head=NULL,*new,*temp;
void create(struct node **head,int t)
{
    new=(struct node*)malloc(sizeof(struct node));
    new->data=t;
    new->next=*head;
    *head=new;
}


void print()
{
    temp=head;
    while(temp!=NULL)
    {
        printf("%d ",temp->data);
       // printf("=%u\n",temp->next);
        temp=temp->next;
    }
    // printf("=%u\n",head);
    printf("\n");
}

void rev1(struct node **head)
{
     struct node *pre=NULL,*cur,*nxt=NULL;
     cur=*head;
    while(cur!=NULL)
    {
        nxt=cur->next;
        cur->next=pre;
        pre=cur;
        cur=nxt;
    } *head=pre;
    
}
void delete(struct node **head,int data)
{

    struct node *pre, *current, *nextnode;
    current = *head;

    if (current->data == data) {
        *head = current->next;
        free(current);
    } else {
        while (current != NULL) {
            if (current->data == data) {
                nextnode = current->next;
                pre->next = nextnode;
                free(current);
                break; 
            }
            pre = current;
            current = current->next;
        }
    }    
}


int main()
{
    for(int i=10;i<13;i++)
    {
        create(&head,1);
        
    }
    create(&head,2);
    create(&head,5);
    create(&head,2);
    create(&head,1);
    create(&head,6);
     print();
    delete(&head,2);
    rev1(&head);
    print();

}
