#include <stdio.h>
#include <string.h>

struct contacts {
    char name[20];
    int phonenum;
    char email[20];
}con[5];
static int i;
void print(struct contacts *p,int i) {
    printf("Name: %s\n", (p+i)->name);
    printf("Phone num: %d\n", (p+i)->phonenum);
    printf("Email address: %s\n",(p+i)->email);
}
void add(struct contacts *p)
{

    printf("Enter the name\n");
    scanf("%s",(p+i)->name);
    printf("Enter 10 digit phone num\n");
    scanf("%d",&(p+i)->phonenum);
    printf("Enter a email address\n");
    scanf("%s",(p+i)->email);
    i++;
  //  return con;
}
int search(struct contacts *p,char *name)
{
    int j;
    for(j=0;j<=i;j++)
    {
        if(!strcmp((p+j)->name,name))
        {
            print(p,j);
            return 0;
        }
    }
    printf("Not in list\n");
    return 0;
}
 void display(struct contacts *p)
 {
     int k;
     for(k=0;k<i;k++)
     {
         print(p,k);
     }
 }
int main()
{
  struct contacts con[5];
  struct contacts *ptr;
  ptr=con;
  int choice;
  char na[10];
  while(1)
   {
      printf("Enter the choice\n");
      printf("1.Add a contact number\n");
      printf("2.Search a contact number\n");
      printf("3.Display contact numbers\n");
      printf("4.Exit\n");
      scanf("%d",&choice);
  
            switch(choice)
            {
                          case 1:
                            add(ptr);
                            break;
                        
                          case 2:
                            printf("enter the name to search\n");
                            scanf("%s",&na);
                            search(ptr,na);
                            break;
                            
                          case 3:
                            display(ptr);
                             break;
                             
                          case 4:
                              return 0;

			  default:
			      printf("invalid key\n");
			      exit(1);
			      
            } 
    }
}

