#include<stdio.h>
int prime(int num)
	{
	int count=0;
    int j;
		for(j=1;j<num;j++)
		{
			if(num%j==0)
			{
				count++;
			}
			     if(count==1)
				{
				//	printf("%d\n",num);
					return num;
				}
				else
				{
				  return 0;
				}
		}
	}
int fun(int num)
{
 

    for (int i = 2; i <= num / 2; i++) {
        if (prime(i) && prime(num - i)) {
            printf("%d + %d= %d\n", i, num - i,num);
           return num;
        }
        else
        {
            printf("not found");
        }
    }
    return 0;

}

int main()
{
	int i,j,num;
	printf("enter the prime number\n");
	scanf("%d",&num);

	if (num >= 2) 
	{
	    	fun(num);
    }
    else
    {
        printf("not a prime num");
    }
	
	
       return 0;	
}


