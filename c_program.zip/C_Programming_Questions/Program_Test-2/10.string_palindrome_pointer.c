#include<string.h>
#include <stdio.h>
int palindrome(char *s,int n)
{
    int st=0,l=n-1;
    while(st<l)
    {
        if(((('a'<=*(s+st))&&('z'>=*(s+st)))||(('A'<=*(s+st))&&('Z'>=*(s+st))))&&((('a'<=*(s+l))&&('z'>=*(s+l)))||(('A'<=*(s+l))&&('Z'>=*(s+l)))))
        {
            if(s[st]!=s[l])
            {
                return 0;
            }
            st++;
            l--;
        }
        else
        {
            if(!((('a'<=*(s+st))&&('z'>=*(s+st)))||(('A'<=*(s+st))&&('Z'>=*(s+st)))))
            {
                st++;
            }
            else if(!((((('a'<=*(s+l))&&('z'>=*(s+l)))||(('A'<=*(s+l))&&('Z'>=*(s+l)))))))
            {
                l--;
            }
        }
    }
    return 1;
}
int main()
{
    char s[200];
    scanf("%[^\n]s",s);
    int n=strlen(s);
    int m=palindrome(s,n);
    if(m==1)
    {
        printf("given str is palindrome\n");
    }
    else
    {
        printf("not palindrome\n");
    }
 
    return 0;
}

