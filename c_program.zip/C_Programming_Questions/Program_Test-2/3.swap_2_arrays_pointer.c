#include<stdio.h>
int main()
{
	int a[5]={1,2,3,4,5};
	int b[5]={6,7,8,9,10};
	int *p1,*p2,n=5;
	p1=a;
	p2=b;
	int temp=0,i;
	for(i=0;i<5;i++)
	{
		temp=*(p2+i);
		*(p2+i)=*(p1+i);
		*(p1+i)=temp;
	}
	for(i=0;i<5;i++)
	{
		printf("a[%d]=%d\n",i,a[i]);

	}
	 for(i=0;i<5;i++)
        {
                printf("b[%d]=%d\n",i,b[i]);
        }
}


