#include<stdio.h>

int main()
{
	FILE *f1,*f2;
	f1=fopen("txt1.c","a+");
	f2=fopen("txt2.c","r");

	if((f1==NULL)||(f2==NULL))
	{
		perror("error opening files");
		return 1;
	}
	char buff[200];
	char ch;
	int i=0;
	while(1)
	{
		 ch = fgetc(f2);
       		if(ch==EOF)
      		 {
			break;
       	       	}
		buff[i]=ch;
		i++;
	}
	int j;
	for(j=0;j<i;j++)
	{
		fputc(buff[j],f1);
		printf("%c",buff[j]);

	}
	fclose(f1);
	fclose(f2);
}

	
