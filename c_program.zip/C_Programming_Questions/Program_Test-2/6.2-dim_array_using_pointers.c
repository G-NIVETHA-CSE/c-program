#include<stdio.h>
#include<stdlib.h>
#define r 2
#define c 2
int main()
{
	int **a;
	int i,j;
	a=(int**)malloc(r*sizeof(int*));
	for(i=0;i<r;i++)
	{
		a[i]=(int*)malloc(c*sizeof(int));
	}
	printf("enter the elements");
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			scanf("%d",(*(a+i)+j));
		}
	}
	 for(i=0;i<r;i++)
        {
                for(j=0;j<c;j++)
                {
                        printf("%d ",*(*(a+i)+j));
                }
        }
}



