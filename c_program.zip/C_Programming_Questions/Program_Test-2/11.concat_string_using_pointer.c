//concatenate 2 strings using pointer
#include <stdio.h>

int main() {
    char a[30] = "online";
    char b[] = "compiler";
    char *ptr = a;
    char *ptr1 = b;
    int count = 0, i;

    while (*ptr != '\0') {
        count++;
        ptr++;
    }
   printf("%d",count);
    while (*ptr1 != '\0') {
        *(ptr) = *ptr1;
        ptr++;
        ptr1++;
       printf("%s\n", a);
    }
    *(ptr) = '\0';
    printf("%s", a);
    
    return 0;
}
