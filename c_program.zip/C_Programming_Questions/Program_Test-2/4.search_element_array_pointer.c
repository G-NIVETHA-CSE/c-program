#include<stdio.h>
int search(int *a,int n,int data)
{
	int i;
	for(i=0;i<n;i++)
	{
	  if(a[i]==data)
	  {
		return 0;
        	}
	}
	return 1;
}

int main()
{
	int n;
	printf("enter the range\n");
	scanf("%d",&n);
	int a[n],i;
	printf("enter the array elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int data;
	printf("enter the dATA to  search");
	scanf("%d",&data);
	int t=search(a,n,data);
	(t==0)?printf("search element available"):printf("not available");
	return 0;
}

