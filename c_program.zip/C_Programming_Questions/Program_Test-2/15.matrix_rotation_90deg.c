#include<stdio.h>
#define r 3
#define c 3

void print(int a[][c])
{
    int i,j;
    for(i=0;i<r;i++)
        {
              for(j=0;j<c;j++)
              {
                printf("%d ",a[i][j]);
              }
              printf("\n");
        }
}
void printclock(int a[][c])
{
  int i,j; 
    for(i=0;i<r;i++)
        {
              for(j=c-1;j>=0;j--)
              {
            //   c[i][j]=a[j][i];
               
                printf("%d ",a[j][i]);
              }
              printf("\n");
        }
}
void printanticlock(int a[][c])
{
printf("A-Cloclwise rotation of Matrix..\n");
    for(int i=r-1; i>=0;i--){
        for(int j=0; j<c; j++)
        {
            printf("%d ",a[j][i]);
        }
        printf("\n");
    }
    }
int main()
{
        int a[r][c];
        int i,j;
        printf("enter the element\n");
         for(i=0;i<r;i++)
        {
              for(j=0;j<c;j++)
              {
                scanf("%d",&a[i][j]);
              }
        }
         print(a);
          printf("Clockwise rotation \n");
         printclock(a);
         printf("Anti-clockwise rotation \n");
         printanticlock(a);
        
}
