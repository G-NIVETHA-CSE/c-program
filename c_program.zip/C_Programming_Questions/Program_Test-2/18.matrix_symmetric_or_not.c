#include<stdio.h>
#include <stdlib.h>
#define r 3
#define c 3

void print(int **a)
{
    int i,j;
    for(i=0;i<r;i++)
        {
              for(j=0;j<c;j++)
              {
                printf("%d ",*(*(a+i)+j));
              }
              printf("\n");
        }
}
int symm(int **a)
{
    int i,j;
	 for(i=0;i<r;i++)
        {
              for(j=0;j<c;j++)
              {
                if(*(*(a+i)+j)!=*(*(a+j)+i))
                {
                   return 0;
                }
              }
        
        }
        return 1;
 }


int main()
{
        int **a;
        int i,j;
        a=(int**)malloc(r*sizeof(int*));
           for(i=0;i<r;i++)
            {
             a[i]=(int*)malloc(c*sizeof(int));
            }
        
        printf("enter the element\n");
         for(i=0;i<r;i++)
        {
              for(j=0;j<c;j++)
              {
                scanf("%d",(*(a+i)+j));
              }
        }
         print(a);
	  int d=symm(a);
	  (d==1)?printf("matrix is symmmetrical"):printf("matrix is asymmmetrical");         
        
}
