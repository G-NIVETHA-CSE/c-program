#include <stdio.h>
#define r 3
#define c 3

void print(int a[][c]) {
    int i, j;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
}

void rotate(int a[][c]) {
    int i, j, k;
    int d[r][c];

    printf("How many times to rotate: ");
    scanf("%d", &k);
   printf("%d times rotated array\n",k);
    while (k--) {
        for (i = 0; i < r; i++) {
            for (j = 0; j < c; j++) {
                d[i][j] = a[c - 1 - j][i];
            }
        }

        // Copy the rotated array back to the original array 'a'
        for (i = 0; i < r; i++) {
            for (j = 0; j < c; j++) {
                a[i][j] = d[i][j];
            }
        }
       // print(a);
    }
   
}

int main() {
    int a[r][c];
    int i, j;
    printf("Enter the elements:\n");
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    print(a);
    rotate(a);
    print(a);

    return 0;
}

