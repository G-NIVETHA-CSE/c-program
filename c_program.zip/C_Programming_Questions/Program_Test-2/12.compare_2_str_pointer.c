#include<stdio.h>
int cmp(char *p1,char *p2)
{
        while(*p1||*p2)
        {
        if(*p1!=*p2)
        {

                return 0;
        }
        p1++;
        p2++;
        }
         return 1;
}
int main()
{
        char s[20];
        char s1[20];
        printf("enter the 2 strings\n");
        scanf("%s%s",s,s1);
        (cmp(s,s1)==1)?printf("strings are equal"):printf("strings are not equal");
}

