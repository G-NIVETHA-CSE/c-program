#include<stdio.h>
void lon(char *a)
{
    int i,j,start=0,end=0;
    int lo=0,l1=0,l2=0,tmp=0;
    for(i=0;a[i]!='\0';i++)
    {
        
        if((a[i]==' ')||(a[i+1]=='\0'))
        {
            lo=0;
           start=end;
           end=i;
           lo=end-start;
            printf(" %d ",lo);
        }
        if(tmp<lo)
        {
            tmp=lo;
            l1=start;
            l2=end;
        }
    }
     for(i=l1;i<=l2;i++)
    {
        printf("%c",a[i]);
    }
    
}
int main()
{
    char a[40]="hi world i m learnnnning look program";
    lon(&a);
}
