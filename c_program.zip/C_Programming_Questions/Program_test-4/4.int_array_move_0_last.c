#include<stdio.h>
int main()
{
        int a[5],n=5,j,i,k,temp=0; // 1 0 0 2 0   1 2 0 0 0
        printf("enter the num\n");
        for(i=0;i<n;i++)
        {
        scanf("%d",&a[i]);
        }
        printf("ok");
        int t=n;
        for(i=0;i<t;)
        {
            if((a[i]==0))
            {
                temp=a[i];
                 for(j=i;j<n;j++)
                 {
                     a[j]=a[j+1];
                 }
                 a[j-1]=temp;
                 t--;
            }
            else 
            {
                i++;
            }
        }
        for(i=0;i<n;i++)
        {
            printf("a[%d]=%d\n",i,a[i]);
        }
        return 0;
}
