#include<stdio.h>
int main()
{
    int i,j,n=5,c=0,k=1;
    for(i=1;i<=n;i++)
    {
        if(i%2)
        {
        for(j=0;j<i;j++)
        {
          printf("%d ",c+j+1);
        }
        }
        else
        {
             for(j=i;j>0;j--)
            {
              printf("%d ",c+j);   
            }
        }
      c=c+k;
      k++;
        printf("\n");
    }
}
