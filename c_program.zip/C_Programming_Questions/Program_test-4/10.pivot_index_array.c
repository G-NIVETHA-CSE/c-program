// Online C compiler to run C program online
#include <stdio.h>

int main() {
   int a[6]={10, 12, 3, 4, 0, 3};
   int ls=0,rs=0,sum=0;
   int i,n=6;
   for(i=0;i<n;i++)
    {
        sum+=a[i];
    }
    for(i=0;i<n;i++)
    {
        sum=sum-a[i];
        if(ls==sum)
        {
           printf("the pivot index of his array %d",i);
        }
        ls=ls+a[i];
    }
    
    
    return 0;
}
