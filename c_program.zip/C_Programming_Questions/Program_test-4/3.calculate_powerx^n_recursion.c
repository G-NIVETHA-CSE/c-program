#include<stdio.h>
static int d=1;
int power(int x,int n)
{
        if(n==0)
        {
                return d;
        }
        else
        {
                d=d*x;
                power(x,n-1);
        }
}

int main()
{
        int a,n;
        printf("enter the num");
        scanf("%d",&a);
        printf("enter the power");
        scanf("%d",&n);
        printf("power of %d^ %d=%d",a,n,power(a,n));
        return 0;
}
