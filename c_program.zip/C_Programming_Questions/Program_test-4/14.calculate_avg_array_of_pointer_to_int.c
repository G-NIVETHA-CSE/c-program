#include<stdio.h>
int main()
{
    int *p[5];
    int a[5]={90,92,93,94,95};
    int n=5,i,sum=0;
    for(i=0;i<n;i++)
    {
        p[i]=&a[i];
    }
    for(i=0;i<n;i++)
    {
        sum+=*p[i];
    }
    sum=sum/n;
    printf("the average %d",sum);
}
