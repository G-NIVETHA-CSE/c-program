#include<stdio.h>
#include<string.h>
char swap(char *a,int start,int end)
{
    char temp;
    while(start<end)
    {
        temp=*(a+start);
        *(a+start)=*(a+end);
        *(a+end)=temp;
        start++;
        end--;
    }
    return a;
}
void revwords(char *a)
{
    int i,start=0,end=0;
   int len=strlen(a);
   printf("len %d\n",len);
    for(i=0;a[i]!='\0';i++)
    {
        if((a[i]==' ')||(a[i+1]=='\0'))
        {
            start=end+1;
            end=i-1;
            if((start==1))
            {
                swap(a,start-1,end);
            }
            else if(a[i+1]=='\0')
            {
                end=i;
                start=start+1;
                 swap(a,start,end);
            }
            else
            {
                start=start+1;
             swap(a,start,end);
            }
            printf("%d %d\n",start,end);
            
        }
    }
    printf("%s",a);
}
int main()
{
    char a[]="write a program ";
    int len=strlen(a);
    swap(a,0,len-1);
    revwords(a);
}
