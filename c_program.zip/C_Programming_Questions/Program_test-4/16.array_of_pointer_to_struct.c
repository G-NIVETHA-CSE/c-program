#include <stdio.h>

struct student
{
    char name[50];  // Use an array of characters to store a string
    int mark;
};

int main()
{
    struct student m[5];
    int n = 2, i;

    printf("Enter the student name and mark \n");
    for (i = 0; i < n; i++)
    {
        printf("Student name and mark\n");
        scanf("%s", m[i].name);
        scanf("%d", &m[i].mark);
    }

    struct student *ptr[5];
    for (i = 0; i < n; i++)
    {
        ptr[i] = &m[i];
    }

    for (i = 0; i < n; i++)
    {
        printf("Student name and mark %d\n", i);
        printf("%s  %d\n", ptr[i]->name, ptr[i]->mark);
    }

    return 0;
}

