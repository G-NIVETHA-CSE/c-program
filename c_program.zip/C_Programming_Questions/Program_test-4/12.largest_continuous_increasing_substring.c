
#include <stdio.h>

int main() {
    int a[6]={5,4,2,1,7,9};
    int n=6,i,j,count=0;
    int start=0,end=0,l1=0,l2=0,max=1;
    for(i=0;i<=n;i++)
    {
        if(a[i]>a[i+1])
        {
            end=i;
            count++;
            printf("%d %d\n",end,count);
        }
        else
        {
            start=i+1;
            count=0;
        }
        if(max<count)
        {
            max=count;
            l1=start;
            l2=count;

        }
    }
     printf(" start=%d, end=%d\n",l1,l2);
      
    return 0;
}
