#include <stdio.h>
#define r 3
#define c 3
int main()
{
    int a[9]={1,2,3,4,5,6,7,8,9};
    int b[r][c];
    int i,j,k=0;
    for(i=0;i<r;i++)
    {
      for(j=0;j<c;j++)
      {
          b[i][j]=a[k];
          k++;
      }
    }
    printf(" 2d array\n");
    for(i=0;i<r;i++)
    {
      for(j=0;j<c;j++)
      {
          printf("b[%d][%d]=%d\n",i,j,b[i][j]);
      }
    }
}

