#include <stdio.h>
void space(char *a,int s)
{
    int i,j;
    printf("%c",a[s-1]);
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]==' ')
        {
            printf("%c",a[i+s]);
        }
    }
    printf("\n");
}
int main()
{
  char a[30]="TO BE OR NOT BE";
  for(int i=1;i<=3;i++)
  {
    space(a,i);
  }
    return 0;
}
