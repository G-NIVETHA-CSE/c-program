#include<stdio.h>
struct student
{
    char name[20];
    int mark;
};
struct student *scan(struct student m[], int n)
{
    for(int i=0;i<n;i++)
    {
    printf("student name AND mark\n");
    scanf("%s",&m[i].name);
    scanf("%d",&m[i].mark);
    }
    return m;
    
}
void print(struct student *ptr, int n)
{
    int i;
     for(i=0;i<n;i++)
    {
    printf("student name AND mark %d\n",i);
    printf("%s  %d\n",(ptr+i)->name,(ptr+i)->mark);
    }
    
}
int main()
{
    struct student m[5];
    struct student *ptr;
    int n=2,i;
    printf("enter the student name and mark \n");
     ptr=scan(m,2);
    print(ptr,n);
    
}
