#include<stdio.h>
struct student
{
    char name[20];
    int mark;
};
void fun(struct student *ptr[], int n)
{
    int i;
     for(i=0;i<n;i++)
    {
    printf("student name AND mark %d\n",i);
    printf("%s  %d\n",ptr[i]->name,ptr[i]->mark);
    }
    
}
int main()
{
    struct student m[5];
    int n=2,i;
    printf("enter the student name and mark \n");
    for(i=0;i<n;i++)
    {
    printf("student name AND mark\n");
    scanf("%s",&m[i].name);
    scanf("%d",&m[i].mark);
    }
    
    struct student *ptr[5];
    for(i=0;i<n;i++)
    {
        ptr[i]=&m[i];
    }
    fun(&ptr,n);
}
