#include<stdio.h>
int main()
{
  int a[8]={4,3,2,6,8,2,3,1};
  int max=0,min=1;
  int flag;
  int i,k,n=8;
  for(i=0;i<n;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
    printf("output:");
    for(k=1;k<=max;k++)
    {
        flag=0;
        for(i=0;i<n;i++)
        {
        if(k==a[i])
        {
          flag=1;
        }
        }
        if(flag==0)
        {
            printf("%d ",k);
        }
    }
    return 0;
}

