// Online C compiler to run C program online
#include <stdio.h>

int main() {
   int a[6]={1,1,1,0,1,1};
  
   int i,n=6,max=0,count=0;
   
    for(i=0;i<n;i++)
    {
            if(a[i]!=1)
            {
                count=0;
            }
            else
            {
                count++;
            }
            
            if(max<count)
            {
                max=count;
            }
    }
    printf("the consective 1's %d",max);
      
    
    return 0;
}
