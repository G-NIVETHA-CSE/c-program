// Online C compiler to run C program online
#include <stdio.h>

int main() {
    int a[6]={50,3,10,7,40,80};
    int n=6,i,j,count=1;
    for(i=0;i<n-1;i++)
    {
        if(a[i]>a[i+1])
        {
        }
        else
        {
            count++;
        }
    }
  printf("%d",count);
    return 0;
}
