#include <stdio.h>
#include<math.h>
int armstrong(int a)
{
    int n=0,b,count=0,c=0;
    n=a;
    while(n!=0)
    {
        n=n/10;
        count++;
    }
    while(a!=0)
    {
        b=a%10;
        a=a/10;
        c=c+pow(b,count);
    }
    return c;
}
int main() {
  int num;
  printf("enter the number\n");
  scanf("%d",&num);
  int check=armstrong(num);
  (check==num)?printf("It is Armstrong number"):printf("It is not Armstrong number");
  
    return 0;
}
