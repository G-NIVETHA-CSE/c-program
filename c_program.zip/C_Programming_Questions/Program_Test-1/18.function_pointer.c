#include <stdio.h> 
void add(int a, int b) 
{ 
    printf("Addition is %d\n", a+b); 
} 
void sub(int a, int b) 
{ 
    printf("Subtraction is %d\n", a-b); 
} 
void multi(int a, int b) 
{ 
    printf("Multiplication is %d\n", a*b); 
} 
  
int main() 
{ 
    void (*fun[])(int, int) = {add, sub, multi}; 
    int ch, a,b; 
    printf("enter the number a and b");
    scanf("%d %d",&a,&b);
    printf("Enter Choice:\n0.add\n1.subtract \n2.multiply\n"); 
    scanf("%d", &ch); 
  
    if(ch > 2)
    {
        return 0;
    }
    (*fun[ch])(a, b); 
  
    return 0; 
} 
