#include<stdio.h>
#define row 3
#define col 3
int main()
{
 //int n=5;
 int a[row][col];
 int i,j,k;
 printf("enter the elements of array");
 for(i=0;i<row;i++)
  {
      for(j=0;j<col;j++)
      {
          scanf("%d",&a[i][j]);
      }
  }
 printf("boundary elements in matrix\n");
 for(i=0;i<row;i++)
  {
      for(j=0;j<col;j++)
      {
          if((i==0)||(j==0)||(i==(row-1))||(j==(col-1)))
          {
              printf("%d ",a[i][j]);
          }
          else
          {
              printf("  ");
          }
      }
      printf("\n");
  }
  
  return 0;
 }
