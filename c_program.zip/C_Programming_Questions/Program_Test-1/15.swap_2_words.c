#include<stdio.h>
int main()
{
	int num,a=0;
	printf("enter the num\n");
	scanf("%x",&num);
	a=((num&0x00ff)<<8)|((num&0xff00)>>8);
	printf("%x",a);
	return 0;
}
