#include <stdio.h>
#include <string.h>

static int i = 0;

void concat(char *s1, char *s2)
{
    if (s2[i] != '\0')
    {
        s1[strlen(s1)] = s2[i];
        i++;
        concat(s1, s2);
    }
}

int main() {
    char str1[20], str2[10];
    printf("Enter the string1:\n");
    scanf("%s", str1);
    printf("Enter the string2:\n");
    scanf("%s", str2);
    concat(str1, str2);
    printf("%s\n", str1);
    return 0;
}

