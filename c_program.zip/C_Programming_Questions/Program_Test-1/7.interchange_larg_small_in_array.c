#include <stdio.h>
int main() {
   int a[10],range=5;
   int i,j,max,small,temp;
    printf("Enter the array element\n");
    for(i=0;i<range;i++)
    {
       scanf("%d",&a[i]); 
    }
    max=0;
    small=0;
    for(i=0;i<range;i++)
    {
            if(a[max]<a[i])
            {
                max=i;
            }
          else if(a[small]>a[i])
            {
              small=i;  
            }
    }
    printf("max %d",max);
    printf("small %d\n",small);
    
    temp=a[max];
    a[max]=a[small];
    a[small]=temp;
    
     printf("swap num");
    for(i=0;i<range;i++)
     printf("%d,", a[i]);
    
    return 0;
}

