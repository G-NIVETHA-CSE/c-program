#include<stdio.h>  
 
int main()  
{  
int i = 1, num, Sum = 0;  
printf(" Enter a number to check Perfect Number \n");  
scanf("%d", &num);  
  
		while(i < num )  
                     {  
                               if(num % i == 0)
                               {  
                               Sum = Sum + i;  
                               }  
                               i++;
                     }  
           if(Sum == num)  
                  printf("\n %d is Perfect Number\n", num);  
           else  
           printf("\n %d is not a Perfect Number\n", num);  

}   
