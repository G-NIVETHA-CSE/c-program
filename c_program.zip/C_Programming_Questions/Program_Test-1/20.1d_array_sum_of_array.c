#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n=5,i,sum=0;
	int *a=(int*)malloc(n*sizeof(int));
	printf("enter the array elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",(a+i));
	}
	for(i=0;i<n;i++)
	{
		sum=sum+*(a+i);
	}
	printf("sum of all elements %d\n",sum);
	return 0;
}



