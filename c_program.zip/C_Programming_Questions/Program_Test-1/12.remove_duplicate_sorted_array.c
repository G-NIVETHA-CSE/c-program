#include<stdio.h>
int main()
{
 int n=5;
 int a[5];
 int i,j,k;
 printf("enter the elements of array");
 for(i=0;i<n;i++)
  {
   scanf("%d",&a[i]);
  }
 for(i=0;i<n;i++)
 {
  for(j=i+1;j<n;j++)
  {
	  if(a[i]==a[j])
	  {
		for(k=j;k<n-1;k++)
		{
			a[k]=a[k+1];
                 }
		n--;
	  }
  }
 }
 for(i=0;i<n;i++)
  {
   printf("%d,",a[i]);
  }
 }
