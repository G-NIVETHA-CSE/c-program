// Online C compiler to run C program online
#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next; 
};
struct node *head=NULL,*new;
void create(struct node **head,int t)
{
    new=(struct node*)malloc(sizeof(struct node));
    new->data=t;
    new->next=*head;
    *head=new;
}
void print(struct node **head)
{
    struct node *temp;
    temp=*head;
    while(temp!=NULL)
    {
        printf("%d  ",temp->data);
        temp=temp->next;
    }
}
void del(struct node **head,int data)
{
    struct node *pre=NULL,*cur,*nxt=NULL;
    cur=*head;
    
       
            if(cur->data==data)
            {
                *head=cur->next;
                free(cur);
            }
            else
            {
                while(cur!=NULL)
                {
                    if(cur->data==data)
                    {
                        nxt=cur->next;
                        pre->next=nxt;
                        free(cur);
                    }
                    pre=cur;
                    cur=cur->next;
                }
        
            }
        
    
}
/*
void del_dup(struct node **head)
{
    struct node *temp=NULL, *temp1=NULL;
   temp=*head;
  //  temp1=*head->next;
    while(temp!=NULL)
    {
        temp1=temp->next;
        while(temp1!=NULL)
        {
            if(temp->data==temp1->data)
            {
                del(head,temp1->data);
            }
            else
            {
                temp1=temp1->next;
            }
        }
        temp=temp->next;
    }
}*/
void del_dup(struct node **head) {
    struct node *current = *head;

    while (current != NULL) {
        struct node *runner = current;
        while (runner->next != NULL) {
            if (current->data == runner->next->data) {
                struct node *temp = runner->next;
                runner->next = runner->next->next;
                free(temp);
            } else {
                runner = runner->next;
            }
        }
        current = current->next;
    }
}

int main()
{
    printf("null-> ");
 create(&head,1);
 create(&head,2);
  create(&head,3);
 create(&head,4);
 create(&head,3);
  create(&head,3);
  create(&head,3);
  
 print(&head);
 del_dup(&head);
 printf("<-head\n");
 print(&head);
}
