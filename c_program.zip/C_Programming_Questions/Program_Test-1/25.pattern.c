#include <stdio.h> 
#include <stdlib.h>
int main() 
{ 
   int i,j,n,l=0;
   printf("enter the range");
   scanf("%d",&n);
   for(i=-n;i<=n;i++)
   {
     l=abs(i);
   // printf("l=%d\n",l);

       for(j=-n;j<=n;j++)
       {
	    //   printf("l=%d\n",l);
           if(abs(j)<=(n-l))
           {
               printf("%d",abs(j)+1);
           }
           else
           {
               printf(" ");
           }
           
       }
       printf("\n");
   }
  
    return 0; 
} 
