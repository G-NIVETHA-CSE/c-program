#include<stdio.h>
int main()
{
	int a;
	int p1,p2;
	printf("enter the num\n");
	scanf("%x",&a);
	int i;
	printf("enter the pos1 and pos2\n");
	scanf("%d%d",&p1,&p2);
	for(i=p2;i<=p1;i--)
	{
	 if(a&(1<<i))
	  {
	  printf("1");
	  }
	  else
	  {
	  printf("0");
	  }
	 }
	 
}
