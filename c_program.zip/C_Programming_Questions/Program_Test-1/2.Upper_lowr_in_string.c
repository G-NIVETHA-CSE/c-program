// Online C compiler to run C program online
#include <stdio.h>
char upper_to_lower(char *a)
{
    int i;
    for(i=0;a[i]!='\0';i++)
    {
        if((a[i]>='A')&&(a[i]<='Z'))
        {
            a[i]+=' ';
        }
      
    }
      return a;
}
int main() {
  char a[20];
  printf("enter the string\n");
  scanf("%s",a);
  upper_to_lower(a);
  printf("the uppercase_to_lowercase string %s\n",a);
    return 0;
}
