#include <stdio.h>
#include <math.h>
int main()
{
    int a;
    printf("enter the range\n");
    scanf("%d",&a);
    int i,j,k=0,l;
   for(i=-a;i<=a;i++)
   {
       if(i<0)
       {
           l=-i;
       }
       else
       {
           l=i;
       }
      
       for(j=0;j<=(a-l);j++)
       {
           if(((j+(a-l))%2)!=0)
           {
               printf("* ");
           }
           else
           {
               printf("  ");
           }
       }
       printf("\n");
   }
    return 0;
}

/*

enter the range
4
*   
  *   
*   *   
  *   *   
*   *   
  *   
*   
 
*/
