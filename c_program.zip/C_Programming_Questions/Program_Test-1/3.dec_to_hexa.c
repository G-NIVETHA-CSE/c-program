#include <stdio.h>
#include <math.h>
int swap(int a,int n)
{
    int b=0;
    for(int i=(n-4),j=0;i<n;i++,j++)
    {
        if(a&(1<<i))
        {
            b=b+pow(2,j);
        
        }
    }
  
    return b;
}
int main() {
int a; //0x41;
int d,c;
printf("enter the decimal num");
scanf("%d",&a);
int size=sizeof(int)*8;
int i,count,b;

for(i=size-1;i>0;i--)
{
    if((i+1)%4==0)
     {
         d=swap(a,i+1);
         if((d>=10) && (d<=15))
         {
             printf("%c",(d+55));
         }
         else
         {
         printf("%d",d);
         }
     }
}
    return 0;
}
