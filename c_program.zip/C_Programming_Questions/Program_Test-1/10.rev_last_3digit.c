// reverse the last 3 digits of a given 6 digit num
#include<stdio.h>

int main()
{
	int num;
	printf("enter the 6 digit num\n");
	scanf("%d",&num);
	int i,b=0,c=0;
	for(i=0;i<3;i++)
	{
		c=num%10;
		num=num/10;
		b=b*10+c;
	}
	printf("num is %d",num);
	num=num*1000;
	num=num+b;
	printf("the last 3 digit rev num %d",num);
	return 0;
}

