#include<stdio.h>
int large(int a[],int n)
{
	int i,max=a[0];
	for(i=0;i<n;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
		}
	}
	return max;
}

int main()
{
	int n;
	printf("enter the range");
	scanf("%d",&n);
	int a[n];
	printf("enter the array elements");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	large(a,n);
	printf("the max number=%d",large(a,n));
}
