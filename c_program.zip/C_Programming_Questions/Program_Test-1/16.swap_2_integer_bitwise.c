#include<stdio.h>
int main()
{
	int num1,num2;
	printf("enter the 2 numbers");
	scanf("%d%d",&num1,&num2);
	num1^=num2;
	num2^=num1;
	num1^=num2;
	printf("num1=%d\nnum2=%d\n",num1,num2);
}
