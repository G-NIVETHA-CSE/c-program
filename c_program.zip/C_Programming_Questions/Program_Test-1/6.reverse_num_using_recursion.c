#include <stdio.h>
int revrec(int num)
{
    static int b,c;
    if(num)
    {
        b=num%10;
        num=num/10;
        c=c*10+b;
        revrec(num);
    }
    else
    {
        return c;
    }
}
int main() {
   int num;
    printf("Enter the number\n");
    scanf("%d",&num);
    printf("%d\n", revrec(num));
    return 0;
}

