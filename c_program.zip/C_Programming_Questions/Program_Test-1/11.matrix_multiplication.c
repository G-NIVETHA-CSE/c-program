#include<stdio.h>
#define row 3
#define col 3
int main()
{
    int a[row][col]={1,2,3,4,5,6,7,8,9};
    int b[row][col]={1,2,3,4,5,6,7,8,9};
    int c[row][col];
    int i,j;
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
                c[i][j]=0; 
                for(int k=0;k<col;k++)    
                {    
                    c[i][j]+=a[i][k]*b[k][j];    
                } 
           
        }
    }
     for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
           printf("%d ",c[i][j]);
        }
        printf("\n");
    }
    
}
