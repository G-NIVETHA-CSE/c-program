
#include <stdio.h> 

int main() 
{ 
   int i,j,n=4,c=0;
   int a=0,b=1;
   for(i=1;i<=n;i++)
   {
       for(j=0;j<i;j++)
       {
           c=a+b;
           printf("%d ",b);
           a=b;
           b=c;
         
       }
       printf("\n");
   }
  
    return 0; 
} 

/*
 1 
1 2 
3 5 8 
13 21 34 55 
 */
