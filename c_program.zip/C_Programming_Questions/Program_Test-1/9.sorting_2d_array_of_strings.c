#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void sort2d(char **a,int n)
{
	char *temp;
	temp=(char*)calloc(20,sizeof(char));

    int i,j;
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
             if(strcmp(a[j],a[j+1])>0)
             {
                 strcpy(temp,a[j]);
                 strcpy(a[j],a[j+1]);
                 strcpy(a[j+1],temp);
             }
        }
    }
    free(temp);
    
}
int main()
{
    char **a;
    int n=5;
    a=(char**)calloc(n,sizeof(char*));
    int i;
     printf("enter 2d strings\n");
    for(i=0;i<n;i++)
    {
        a[i]=(char*)calloc(20,sizeof(char));
        scanf("%s",a[i]);
        printf("\n");
    }
     sort2d(a,n);
    printf("after sort \n");
    for(i=0;i<n;i++)
    {
        printf("%s\n",a[i]);
    }

    free(a);
    
}
