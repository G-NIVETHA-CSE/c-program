// Online C compiler to run C program online
#include<stdio.h>
//#include<stdlib.h>
int main()
{
    int range,i,j,pos;
    printf("enter the range");
    scanf("%d",&range);

  int a[range];
    printf("enter the array elments");
  for(i=0;i<range;i++)
  {
      scanf("%d",&a[i]);
  }
    printf("enter the position to rotate");
    scanf("%d",&pos);

int temp;
  for(i=0;i<pos;i++)
  {
      temp=a[range-1];
      for(j=0;j<range;j++)
      {
          a[range-j]=a[range-j-1];
      }
      a[0]=temp;
      printf("%d\n",temp);
  }
    for(i=0;i<range;i++)
  {
    printf("%d",a[i]);
  }
    return 0;
}
