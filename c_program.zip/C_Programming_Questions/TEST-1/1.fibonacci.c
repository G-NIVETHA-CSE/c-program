// Online C compiler to run C program online
#include <stdio.h>

int main() {
    int n,a=0,b=1,c;
    printf("enter the fibonacci series range");
    scanf("%d",&n);
    n=n-2;
    printf("%d\n%d\n",a,b);
    while(n)
    {
        c=a+b;
        printf("%d\n",c);
        a=b;
        b=c;
        n--;
    }

    return 0;
}
