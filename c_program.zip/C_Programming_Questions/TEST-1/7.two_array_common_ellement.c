//given two arrays find the common elements
#include<stdio.h>
void main()
{
	int a[]={1,2,3,4,4,5,6,7,8,9,9,9,9};
	int b[]={4,5,6,7,8,4,4,4,4,7,6,9};
	int s1=sizeof(a)/sizeof(a[0]);
	int s2=sizeof(b)/sizeof(b[0]);
	int s3=s1>s2?s1:s2;
	int c[s3],k=0,temp=0,flag=0;
	for(int i=0;i<s1;i++)
	{
		for(int j=0;j<s2;j++)
		{
			if(a[i]==b[j])
			{
			flag=0;
			for(temp=0;temp<=k;temp++)
			{
    			if(c[temp]==a[i])
    			flag++;
			}
    			if(flag)
    			break;
    			
			temp=k;
			c[k++]=a[i];
			break;
			}
		}
	
	}
	for(int i=0;i<k;i++)
	printf("%d,",c[i]);
}

