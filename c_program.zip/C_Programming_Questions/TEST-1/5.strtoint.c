//convert a string containing a numeric value to integer
#include <stdio.h>
#include <math.h>
int main()
{
    char a[10];
    printf("enter the  character\n");
    scanf("%s",&a);
    int i,b=0;
   for(i=0;a[i]!='\0';i++)
   {
       if((a[i]>='0')&&(a[i]<='9'))
       {
           a[i]=a[i]-48;
           b=b*10+a[i];
          // printf("%d",b);
       }
   }
   printf("%d",b);
    return 0;
}
