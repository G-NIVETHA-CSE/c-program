#include<stdio.h>
int main()
{
    char a[]="this is my program";
    char b[10];
    int i,pos1,pos2,k=0;
    printf("enter the position to extract\n");
    scanf("%d %d",&pos1,&pos2);
    for(i=pos1;i<=pos2;i++)
    {
      b[k]=a[pos1+k];
      k++;
    }
    b[k]='\0';
    printf("extracted substring %s",b);
}
