#include <stdio.h>
#include <math.h>
int main()
{
    int a;
    printf("enter the  num\n");
    scanf("%d",&a);
   int i,k;
   for(i=1;i<=a/2;i++)
   {
       if((a%i==0))
       {
           k=i*i;
           if(k==a)
           {
               printf("it is a perfect square");
               return 0;
           }
       }
   }
   printf("not a perfect square");
    return 0;
}
