#include<stdio.h>
#include<stdlib.h>

struct node
{
 int data;
 struct node *next;
};

struct node *head=NULL,*new,*temp=NULL;

void enqueue(struct node **head, int t)
{
  new=(struct node*)malloc(sizeof(struct node));
  temp=*head;
  new->data=t;
  new->next=NULL;
  
  if(temp==NULL)
  {
    temp=new;
  }
  else
  {
    temp=*head;
    while((temp->next)!=NULL)
    {
       
      temp=temp->next;
    }
     temp->next=new;
  }*head=temp;
}
void display(struct node **head)
{
    temp=*head;
    if(temp==NULL)
    {
        printf("list is empty");
    }
    else
    {
        while(temp !=NULL)
        {
            printf("%d\n",temp->data);
            temp=temp->next;
        }
    }

}
void dequeue(struct node **head)
{
	temp=*head;
	if(temp==NULL)
	{
		printf("list is empty \n");
	}
	else
	{
		*head=temp->next;
		free(temp);
	}
}

int main()
{
  // printf("list of queues");
    enqueue(&head,1);
    enqueue(&head,2);
    enqueue(&head,3);
    enqueue(&head,4);
    printf("display queues\n");
    display(&head);
    printf("delete a element in queue(FIFO)\n");
    dequeue(&head);
    display(&head);
}
