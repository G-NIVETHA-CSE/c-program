#include<stdio.h>
int main()
{
    int range;
    printf("enter the range");
    scanf("%d",&range);

  int a[range];
  int i,n1,n2;
  printf("enter the array elements");
  for(i=0;i<range;i++)
  {
      scanf("%d",&a[i]);
  }
  n1=0;
    for(i=0;i<range;i++)
    {
        n1^=a[i];
    }
    for(i=1;i<=(range+1);i++)
    {
        n1^=i;
    }

    printf("%d",n1);
    return 0;
}

