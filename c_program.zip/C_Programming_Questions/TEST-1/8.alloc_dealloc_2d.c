#include<stdio.h>
#include<stdlib.h>
int main()
{
    int rows,cols;
    printf("enter the rows and column");
    scanf("%d%d",&rows,&cols);
    int **a;
    int i,j;
    a=(int**)malloc(rows*sizeof(int*));
    for(i=0;i<rows;i++)
    {
      a[i]=(int*)malloc(cols*sizeof(int));
    }
     for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &a[i][j]);
        }
        printf("\n");
    }
     for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
     for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            //free(a[i][j]);
        }
        printf("\n");
    }
    free(a);
}
