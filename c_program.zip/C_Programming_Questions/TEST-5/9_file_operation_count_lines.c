//c program that counts and displays the no of lines in a txt file

#include <stdio.h>

int main() {
    FILE *file;
    char filename[100];
    char ch;
    int lineCount = 0;

    printf("Enter the filename: ");
    scanf("%s", filename);

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("File not found or cannot be opened.\n");
        return 1;
    }

    while ((ch = fgetc(file)) != EOF) {
        if (ch == '\n') {
            lineCount++;
        }
    }

    fclose(file);

    printf("Number of lines in %s: %d\n", filename, lineCount);

    return 0;
}

