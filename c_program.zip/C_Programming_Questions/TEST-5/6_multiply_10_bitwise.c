//multiply a num with 10 using bitwise operators

#include <stdio.h>
int main() {
    int num;
    printf("enter the number");
    scanf("%d",&num);
   int a=(num<<3)+(num<<1);
  printf("%d",a);
    return 0;
}

