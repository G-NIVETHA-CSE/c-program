// Online C compiler to run C program online
#include <stdio.h>

int main() {
  int a[50]={1,2,3,4,5};
  int b[5],i,n=5;
  int size=sizeof(a)/sizeof(a[0]);
  int *ptra=&a;
  int *ptrb=&b;
  for(i=0;i<n;i++)
  {
      *(ptrb+i)=*(ptra+i);
  }
   for(i=0;i<n;i++)
  {
       printf("%d",b[i]);
  }

    return 0;
}
