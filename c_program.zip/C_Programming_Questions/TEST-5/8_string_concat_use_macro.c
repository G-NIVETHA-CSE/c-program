#include<stdio.h>
#include<string.h>
#define con(s1,s2) strcat(s1,s2)
int main()
{
	char s1[200]="hi",s2[200]="bitsilica";
	con(s1,s2);
	printf("%s",s1);
	return 0;
}

