#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *sourceFile, *destinationFile;
    char sourceFileName[100], destinationFileName[100];
    char ch;
    long fileLength;
    char *buffer;

    printf("Enter the source file name: ");
    scanf("%s", sourceFileName);

    printf("Enter the destination file name: ");
    scanf("%s", destinationFileName);

    sourceFile = fopen(sourceFileName, "r");
    if (sourceFile == NULL) {
        printf("Source file not found or cannot be opened.\n");
        return 1;
    }

    destinationFile = fopen(destinationFileName, "w");
    if (destinationFile == NULL) {
        printf("Cannot create or open the destination file.\n");
        fclose(sourceFile);
        return 1;
    }

    // Get the length of the source file
    fseek(sourceFile, 0, SEEK_END);
    fileLength = ftell(sourceFile);
    rewind(sourceFile);

    // Allocate memory for a buffer to store the file content
    buffer = (char *)malloc(fileLength * sizeof(char));
    if (buffer == NULL) {
        printf("Memory allocation error.\n");
        fclose(sourceFile);
        fclose(destinationFile);
        return 1;
    }

    // Read the source file content into the buffer
    fread(buffer, sizeof(char), fileLength, sourceFile);

    // Write the content to the destination file in reverse order
    for (int i = fileLength - 1; i >= 0; i--) {
        fputc(buffer[i], destinationFile);
    }

    printf("Data from %s has been written to %s in reverse order.\n", sourceFileName, destinationFileName);

    // Clean up and close the files
    fclose(sourceFile);
    fclose(destinationFile);
    free(buffer);

    return 0;
}

