//remove a duplicate from an array using pointer

#include <stdio.h>

int main() {
  int a[50] = {1, 2, 3, 2, 5};
  int *ptra = a;
  int i, j, n = 5;
  
  for (i = 0; i < n; i++) {
    for (j = i + 1; j < n;) {
      if (*(ptra + i) == *(ptra + j)) {
        for (int k = j; k < n - 1; k++) {
          *(ptra + k) = *(ptra + k + 1);
        }
        n--;
      } else {
        j++;
      }
    }
  }

  printf("Array after removing duplicates: ");
  for (i = 0; i < n; i++) {
    printf("%d ", *(ptra + i));
  }
  
  return 0;
}

