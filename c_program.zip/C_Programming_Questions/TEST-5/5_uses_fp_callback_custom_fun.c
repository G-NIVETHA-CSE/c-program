//callback using function pointer for custom function

#include <stdio.h>

int Fun(int a, int b, int (*callback)(int, int)) {
    return callback(a, b);
}
int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int mul(int a, int b) {
    return a * b;
}

int main() {
    int result;

    result = Fun(5, 3, add);
    printf("Addition result: %d\n", result);

    result = Fun(5, 3, sub);
    printf("Subtraction result: %d\n", result);

    result = Fun(5, 3, mul);
    printf("Multiplication result: %d\n", result);

    return 0;
}

