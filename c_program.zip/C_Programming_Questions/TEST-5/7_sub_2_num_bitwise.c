// subtract 2 num using bitwise operators

#include <stdio.h>
int sub(unsigned int x,unsigned int y)
{
    int carry;
    while(y!=0)
    {
        carry=(~x)&y;
        x=x^y;
        y=carry<<1;
    }
    return x;
}

int main()
 {
    int num1,num2;
    printf("enter the number");
    scanf("%d %d",&num1,&num2);

  printf("%d",sub(num1,num2));
    return 0;
}
