//8
#include<stdio.h>
#include<string.h>
void main()
{
 char str[]="madamabcdefghgfedcbaramar";
 int len=(strlen(str));
 char strrev[len];
 int i=0,j=0,k=0;
 for(i=0;i<len;i++)
 {
    strrev[i]=str[len-1-i];
  }
  strrev[i]='\0';
  int count=0,temp=0,pos=0;
  for(i=0;str[i];i++)
  {
  for(j=0;j<len;j++)
  {
  	k=0;
  	count=0;
  	if(str[i]==strrev[j])
  	{
  	while(str[i+k]==strrev[j+k])
  	{
  		count++;
  		k++;
  		
  	}
  	}
  	
  	if(temp<count)
  	{
  		temp=count;
  		count=0;
  		pos=i;
  		k=0;
  	}
  }
  }
  for(i=pos;i<pos+temp;i++)
  printf("%c",str[i]);
  }	
  	
