//random number 
#include <stdlib.h>

int main(void) {
  for (int i = 0; i < 10; i++)
    printf(" %d ", rand());

  return 0;
}
