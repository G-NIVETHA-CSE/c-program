#include <stdio.h>
#include<string.h>
void substring(char *a,char *b)
{
    int k,count=0,i;
    int len=strlen(b);
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]==b[0])
        {
            for(k=0;b[k]!='\0';k++)
            {
               if(a[k+i]==b[k])
               {
                count++;
              //  printf("%d",count);
               }
            }
            if(count==len)
            {
                printf("the position of first index of substring %d\n",i);
            }
            count=0;
        }
    }
}
int main()
{
     char *a="hello thiss hello jk hello";
     char *b="hello";
    substring(a,b);
    return 0;
}
