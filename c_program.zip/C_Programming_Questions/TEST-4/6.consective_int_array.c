#include <stdio.h>
void consective(int a[],int n)
{
    int count=1,i,j;
    for(i=0;i<n;i++)
    {
        
        if((a[i]+1)==a[i+1])
        {
            count++;
        }
        else
        {
            int k;
             k=i-count+1; 
            if(count>1)
            {
                printf("the count is %d\n",count);
                printf("the consective element=");
                for(k;count>=1;k++,count--)
                {
                    printf("%d ",a[k]);
                }
               
            }
           
            count=1;
            printf("\n");
        }
    }
}
int main()
{
    int n,i,j;
    printf("enter the range\n");
    scanf("%d",&n);
    int a[n];
    printf("enter the array element\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    consective(a,n);
}
