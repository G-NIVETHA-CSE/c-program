#include <stdio.h>

int main() {
   int n;
   printf("enter the range");
   scanf("%d",&n);
   int a[n],b=0,i,c=0;
   printf("enter the array elements");
   for(i=0;i<n;i++)
   {
   scanf("%d",&a[i]);
   }
   i=0;
   while(i<(n-1))
   {
       if(a[i]!=a[n-1])
       {
           printf("it is not palindrome");
           return 0;
       }
       i++;
       n--;
   }
   printf("it is palindrome");
    return 0;
}
