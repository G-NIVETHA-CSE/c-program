#include <stdio.h>

int binary_loop(int a[], int x, int s) {
    int low = 0, high = s;
    while (low <= high) {
        int mid = low + (high - low) / 2;
        if (a[mid] == x) {
            return 0;
        } else if (x < a[mid]) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }
    return 1;
}

int main() {
    int a[] = {1, 2, 3, 4, 5, 6, 7};
    int n, c;
    int m = sizeof(a) / sizeof(a[0]);
    scanf("%d", &n);
    c = binary_loop(a, n, m - 1);
    if (c == 0) {
        printf("is available\n");
    } else {
        printf("not available\n");
    }
}
