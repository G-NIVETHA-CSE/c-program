#include <stdio.h>
#include <stdlib.h>
int *dup(int *ptra,int n) {
  int i, j;
  
  for (i = 0; i < n; i++) 
  {
    for (j = i + 1; j < n;)
    {
      if (*(ptra + i) == *(ptra + j))
      {
        for (int k = j; k < n - 1; k++)
        {
          *(ptra + k) = *(ptra + k + 1);
        }
        n--;
      } 
      else
      {
        j++;
      }
    }
  }
   printf("\nArray after removing duplicates: ");
  for (i = 0; i < n; i++) {
    printf("%d ", *(ptra + i));
  }

 return ptra;
  
 
}
int main()
{
    int *a;
    int n1=5,n2=5,i;
    a=(int*)malloc(n1*sizeof(int));
    printf("enter the array elements");
    for(i=0;i<n1;i++)
    {
        scanf("%d",&a[i]);
    }
    int b[5]={2,2,3,7,6};
        int n=n1+n2;
    a=realloc(a,n*sizeof(int));

    for(i=0;i<n2;i++)
    {
        a[n1+i]=b[i];
    }
     for (i = 0; i < n; i++)
     {
         printf("%d ",a[i]);
     }
     dup(a,n);
     
    
}
