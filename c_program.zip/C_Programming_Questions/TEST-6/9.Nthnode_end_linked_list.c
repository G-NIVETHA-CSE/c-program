#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *next;
};

struct node *new,*head=NULL;

void create(struct node **head, int t)
{
    new=(struct node*)malloc(sizeof(struct node));
    new->data=t;
    new->next=*head;
    *head=new;
    
}
void print(struct node **head)
{
    struct node *temp;
    temp=*head;
    while(temp!=NULL)
    {
        printf("%d\n",temp->data);
        temp=temp->next;
    }
}
void nth(struct node **head,int n)
{
    struct node *temp;
    temp=*head;
    while(n!=0)
    {
       
        temp=temp->next;
        n--;
    }
     printf("%d\n",temp->data);
}

int main()
{
    int n;
      printf("Null\n");
      create(&head,10);
      create(&head,20);
      create(&head,30);
      create(&head,40);
      print(&head);
      printf("head\n");
      printf("find Nth node from the end \n");
      scanf("%d",&n);
      printf("enter the %dth element =",n);
      nth(&head,n-1);
       
}
