#include <stdio.h>
#include <stdlib.h>
#define row 3
#define col 3
   int i,j;
void diag(int **a)
{
    int sum=0,max=a[0][0];
     for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            if(i==j)
            {
                sum+=a[i][j];
            }
            if(max<a[i][j])
            {
                max=a[i][j];
            }
        }
        
    }
    printf("sum of diagnol %d\n",sum);
    printf("maximum num = %d\n",max);
}
int main()
{
    int **a;
    a=(int**)malloc(row*sizeof(int));
    for(i=0;i<col;i++)
    {
        a[i]=(int*)malloc(col*sizeof(int));
    }
    printf("enter the elements of array");
    printf("\n");
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
            scanf("%d",&a[i][j]);
        }
        
    }
    diag(a);
    free(a);
}
