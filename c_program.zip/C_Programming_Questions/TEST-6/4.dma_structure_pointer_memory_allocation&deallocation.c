#include <stdio.h>
#include <stdlib.h>

// Define a structure
struct Person {
    char name[100];
    int age;
};

int main() {
    int n;
    
    printf("Enter the number of persons: ");
    scanf("%d", &n);

    // Allocate memory for an array of struct Person
    struct Person *people = (struct Person *)malloc(n * sizeof(struct Person));

    if (people == NULL) {
        printf("Memory allocation failed. Exiting...\n");
        return 1;
    }

    // Input details for each person
    for (int i = 0; i < n; i++) {
        printf("Enter name for person %d: ", i + 1);
        scanf("%s", people[i].name);

        printf("Enter age for person %d: ", i + 1);
        scanf("%d", &people[i].age);
    }

    // Display the details for each person
    printf("\nDetails of %d persons:\n", n);
    for (int i = 0; i < n; i++) {
        printf("Person %d - Name: %s, Age: %d\n", i + 1, people[i].name, people[i].age);
    }

    // Free the dynamically allocated memory
    free(people);

    return 0;
}

