#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char *str,temp;
    int len, i;

    printf("Enter a string: ");
    str=(char *)malloc(100 * sizeof(char));

    if (str==NULL)
    {
        printf("Memory allocation failed.\n");
        return 1;
    }

    fgets(str, 100, stdin);
    len = strlen(str);
    for (i=0; i<(len/2); i++) 
    {
        temp=str[len-1-i];
        str[len-1-i]=str[i];
        str[i]=temp;
    }
   
    printf("Reversed string: %s\n",str);
    free(str);
    return 0;
}

