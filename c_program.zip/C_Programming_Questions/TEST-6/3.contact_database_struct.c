#include <stdio.h>
#include <string.h>

struct contacts {
    char name[20];
    int phonenum;
    char email[20];
}con[2];
static int i;
void print(int l) {
    printf("Name: %s\n", con[l].name);
    printf("Phone num: %d\n", con[l].phonenum);
    printf("Email address: %s\n", con[l].email);
}
void add()
{

    printf("Enter the name\n");
    scanf("%s",&con[i].name);
    printf("Enter 10 digit phone num\n");
    scanf("%d",&con[i].phonenum);
    printf("Enter a email address\n");
    scanf("%s",&con[i].email);
    i++;
  //  return con;
}
int search(char *name)
{
    int j;
    for(j=0;j<=i;j++)
    {
        if(!strcmp(con[j].name,name))
        {
            print(j);
            return 0;
        }
    }
    printf("Not in list\n");
    return 0;
}
 void display()
 {
     int p;
     for(p=0;p<i;p++)
     {
         print(p);
     }
 }
int main()
{
  struct contacts con;
  int choice;
  char na[10];
  while(1)
   {
      printf("Enter the choice\n");
      printf("1.Add a contact number\n");
      printf("2.Search a contact number\n");
      printf("3.Display contact numbers\n");
      printf("4.Exit\n");
      scanf("%d",&choice);
  
            switch(choice)
            {
                          case 1:
                            add();
                            break;
                        
                          case 2:
                            printf("enter the name to search\n");
                            scanf("%s",&na);
                            search(na);
                            break;
                            
                          case 3:
                            display();
                             break;
                             
                          case 4:
                              return 0;
            } 
    }
}

