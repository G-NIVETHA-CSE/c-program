#include <stdio.h>
#include <string.h>

struct person {
    char name[50];
    int age;
};

struct person get(char* name, int age) {
    struct person p;
    strcpy(p.name, name);
    p.age = age;
    return p;
}
void print(struct person *p) {
    printf("Name: %s\n", p->name);
    printf("Age: %d\n", p->age);
}

