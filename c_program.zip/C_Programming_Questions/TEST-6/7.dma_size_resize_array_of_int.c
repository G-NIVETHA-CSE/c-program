#include<stdio.h>
#include<stdlib.h>
void print(int *a,int n)
{
	int i; 
	for(i=0;i<n;i++)
        {
                printf("%d\n",a[i]);
        }

}
int main()
{
	int *a;
	int n,n1,i;
	printf("enter the size");
	scanf("%d",&n);
	a=(int*)malloc(n*sizeof(int));
	printf("enter the array");
	for(i=0;i<n;i++)
	{
	 scanf("%d",&a[i]);
	}
	print(a,n);
	printf("enter the new size");
	scanf("%d",&n1);
	a=(int*)realloc(a,sizeof(n1));
	for(i=0;i<n1;i++)
	{
		scanf("%d",&a[i]);
	}
	print(a,n1);

	free(a);




}
