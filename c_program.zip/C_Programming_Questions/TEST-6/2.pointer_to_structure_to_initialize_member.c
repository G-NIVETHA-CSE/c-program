#include<stdio.h>

struct class
{
    int id;
    char name[10];
};
int *fun(struct class *d)
{
    printf("enter the id and name");
    scanf("%d %s",&d->id,&d->name);
    return d;
}
int main()
{
    struct class c;
    fun(&c);
    printf("id=%d\nname=%s",c.id,c.name);
}
