

#include <stdio.h>

struct fp
{
    int(*add)(int,int);
     int(*sub)(int,int);
      int(*mul)(int,int);
};
int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int mul(int a, int b) {
    return a * b;
}

int main() 
{
    struct fp f;
    int a=6,b=1;
    f.add=add(a,b);
    f.sub=sub(a,b);
    f.mul=mul(a,b);
    printf("Arithmetic operations\n");
    printf("add=%d\n",f.add);
    printf("sub=%d\n",f.sub);
    printf("mul=%d\n",f.mul);
    return 0;
}

