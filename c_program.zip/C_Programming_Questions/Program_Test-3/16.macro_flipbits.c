
#include <stdio.h>
#define f(num) ~num
int main() {
    int num;
    printf("enter the num in hex \n");
    scanf("%x",&num);
    printf("num %x\n",f(num));
    return 0;
}
