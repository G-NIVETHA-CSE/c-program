#include<stdio.h>

struct person
{
    char name[10];
    char address[20];
    
    struct location
    {
        char city[20];
        char state[20];
        
    }l;
}p;

int main()
{
    printf("enter the person name and address and city and state\n");
    scanf("%s%s%s%s",&p.name,&p.address,&p.l.city,&p.l.state);
    printf("persons name:%s\n",p.name);
    printf("persons address:%s\n",p.address);
    printf("city:%s\n",p.l.city);
    printf("state:%s\n",p.l.state);
}
