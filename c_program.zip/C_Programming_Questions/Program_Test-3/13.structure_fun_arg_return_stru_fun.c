
#include <stdio.h>

struct date
{
     int day;
     int month;
    int year;
};
struct date fun(struct date d)
{
    d.day=31;
     d.month=12;
     d.year=2021;
     
    return d;
}
int main()
{
    struct date p;
    printf("enter the day month and year\n");
    p=fun(p);
    printf("%d/%d/%d",p.day,p.month,p.year);
}
