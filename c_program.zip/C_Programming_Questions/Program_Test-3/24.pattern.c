#include <stdio.h>
int main() {
    int n=5;
    int i,j,k=0;
    for(i=1;i<=n;i++)
    {
        k=1;
        for(j=1;j<=i;j++)
        {
           if((i%2)==1)
           {
               printf("%d ",k);
               k=k+2;
           }
           else
           {
               printf("%d ",j*2);
              
           }
          
        }
        printf("\n");
    }
   

    return 0;
}

