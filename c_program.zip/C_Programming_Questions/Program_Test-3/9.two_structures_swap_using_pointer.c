#include <stdio.h>
struct student
{
    int x,y;
    
};
void swap(struct student *s,struct student *s1)
{
    struct student temp;
                    temp=*s;
                    *s=*s1;
                    *s1=temp;
}
int main() 
{
  struct student s={1,2};
  struct student s1={3,4};
  swap(&s,&s1);
  printf("s.x=%d s.y=%d\n",s.x,s.y);
   printf("s1.x=%d s1.y=%d",s1.x,s1.y);

    return 0;
}
