#include<stdio.h>
#include<string.h>
void substring(char *a,char *b)
{
    int k,count=0,i,j=0;
    int len=strlen(b);
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]==b[0])
        {
            for(k=0;b[k]!='\0';k++)
            {
               if(a[k+i]==b[k])
               {
                count++;
              //  printf("%d",count);
               }
            }
            if(count==len)
            {
                j=i;
                
            }
            count=0;
        }
    }
    printf("the position of last occur string %d\n",j);
       for(j;a[j]!='\0';j++)
        {
            a[j]=a[j+len];
            
        }
        printf("Removed a substring\n");
    printf("%s\n",a);

    
}
int main()
{
     char a[40]="hellothisshellojkhelloname";
     char b[20]="hello";
     printf("string:\n%s\n",a);
    substring(a,b);
    return 0;
}
