#include <stdio.h>
#define upperlower(c,check) \
        if((c>='A')&&(c<='Z')) \
            check=1;    \
        else if((c>='a')&&(c<='z')) \
            check=2;  \
        else        \
            check=3; 
int main() 
{
    char c;
    printf("enter the character to check uppercase or lowercase\n");
    scanf("%c",&c);
    int check;
    upperlower(c,check)
    (check==1)?printf("uppercase"):(check==2)?printf("lowercase"):printf("not a letter");
   

    return 0;
}
