// Online C compiler to run C program online
#include <stdio.h>
struct student
{
    int marks;
    char name[20];
};
int main() 
{
    int n=2;
  struct student a[5];
  int i;
  printf("enter the average marks of students\n");
  printf("marks and name\n");
  for(i=0;i<n;i++)
  {
      scanf("%d%s",&a[i].marks,&a[i].name);
  }
  int avg;
   for(i=0;i<n;i++)
  {
      avg+=a[i].marks;
  }
  avg=avg/n;
  printf("The average marks of students %d",avg);
  
    return 0;
}
