#include<stdio.h>
#define tog(x,n) x^(1<<n)
int main()
{
	int num,p;
	printf("enter the num(in hex) and nth bit\n");
	scanf("%x",&num);
	scanf("%d",&p);
	printf("the tog %x",tog(num,p));
}
