#include<stdio.h>
int main()
{
	int num; //13233
	printf("enter the num\n");
    scanf("%d",&num);
	int b=0,c=0,count=0;
	int d=num;
	int e=0;
	while(d!=0)
	{
	    b=d%10;//3
	    d=d/10;
	    e=0;
	    count=0;
	    while(d!=0)
	    {
	       
	        c=d%10;
	        if(b==c)
	        {
	            count++;
	        }
	        else
	        {
	            e=e*10+c;
	        }
	   
	        d=d/10;
	    }
	    d=e;
	    printf(" the digit is %d count is %d\n",b,count+1);
	   
	}
	
	}
	
