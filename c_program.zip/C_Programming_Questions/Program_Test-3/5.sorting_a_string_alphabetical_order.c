#include<stdio.h>
int main()
{
    char a[10],temp;
    int i=0,j;
    printf("enter the character \n");
    scanf("%s",a);
    for(i=0;a[i]!='\0';i++)
    {
        for(j=i+1;a[j]!='\0';j++)
        {
            if(a[i]>a[j])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
    }
    printf("%s",a);
}
