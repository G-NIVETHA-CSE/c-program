

#include <stdio.h>

struct date
{
     int day;
     int month;
    int year;
}d;
void fun(struct date *d)
{
     d->day=31;
     d->month=12;
     d->year=2021;
     
}
int main()
{
    struct date *p;
    p=&d;
    printf("enter the day month and year\n");
    fun(p);
    printf("%d/%d/%d",p->day,p->month,p->year);
}
