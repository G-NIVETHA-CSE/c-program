#include <stdio.h>
#define r 3
#define c 3
void check(int a[][c]) {
    int i, j,count=0;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
          if(a[i][j]==0)
          {
              count++;
          }
        }
        //printf("\n");
    }
    int check=(r*c)/2;
    
    (count>check)?printf("it is sparse  matrix\n"):printf("it is not sparse matrix\n");
}
void print(int a[][c]) {
    int i, j;
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
}


int main() {
    int a[r][c];
    int i, j;
    printf("Enter the elements:\n");
    for (i = 0; i < r; i++) {
        for (j = 0; j < c; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    print(a);
    check(a);
    return 0;
}

