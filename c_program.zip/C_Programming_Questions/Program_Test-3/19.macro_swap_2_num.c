#include<stdio.h>
#define swap(x,y) int temp; \
		  temp=x; \
		  x=y; \
		  y=temp; 

int main()
{
	int a,b;
	printf("enter the values a and b\n");
	scanf("%d%d",&a,&b);
	swap(a,b)
	printf("swap a=%d b=%d\n",a,b);
	return 0;
}

