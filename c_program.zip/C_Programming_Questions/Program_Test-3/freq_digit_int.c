#include<stdio.h>
int main()
{
	int num=123222; //13233
	printf("enter the num\n");
	//scanf("%d",&num);
	int b=0,c=0,temp,count=0;
	//temp=num;
	while(num!=0)
	{
		c=num%10;
		temp=num;
		while(temp!=0)
		{
			b=temp%10;
			if(b==c)
			{
			count++;
			}
			else
			{
			num=num*10+b;
			}
			temp=temp/10;
		}
		printf(" the digit %d is %d\n",c,count-1);
		num=num/10;
	}
	}
		
/*
#include<stdio.h>
#include<string.h>
void strrev(char *a)
{
    int i=0,c=0;
    char temp;
    for(i=0;a[i]!='\0';i++)
    {
        c++;
    }
    for(i=0;i<c/2;i++)
    {
        temp=a[c-i-1];
        a[c-i-1]=a[i];
        a[i]=temp;
    }
}

int main()
{
        char a[20],s[20];
        int count=0;
        printf("Enter the string\n");
         gets(a);
        printf("Enter the substring\n");
         gets(s);
         int i,k,l,j;
         l=strlen(s);
           strrev(a);
           strrev(s);
         for(i=0;a[i]!='\0';i++)
         {
             if(a[i]==s[i])
             {
                 for(k=i;s[k]!='\0';k++)
                 {
                     if(a[i+k]==s[k])
                     {
                         count++;
                     }
                 }
                 if(l==count)
                 {
                     for(j=0;j<=count;j++)
                     {
                 	for(k=i;a[k]!='\0';k++)
                     {
		             a[k]=a[k+1];
                    }
                     }
                     strrev(a);
                  printf("%s",a);
                    return 0;
                 }
             }
         }
        
          
       
}
*/
