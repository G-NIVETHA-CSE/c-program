#include <stdio.h>

int main() {
    char *fruits[] = {"Apple", "Banana", "Cherry", "Date", "Fig"};
    char *p[5];
    for (int i = 0; i < 5; i++) {
        p[i] = fruits[i];
    }
    for (int i = 0; i < 5; i++) {
        printf("Fruit %d: %s\n", i + 1, p[i]);
    }

    return 0;
}


