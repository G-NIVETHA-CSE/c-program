#include <stdio.h>

struct date
{
    unsigned int day:6;
     unsigned int month:4;
    int year:12;
};
int main()
{
    struct date d;
    printf("enter the day month and year\n");
     d.day=31;
     d.month=12;
     d.year=2021;
    printf("%d/%d/%d",d.day,d.month,d.year);
}
