#include<stdio.h>
int main()
{
    int i,j,k;
    int n;
    printf("enter the range ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
         k=i;
        for(j=0;j<n;j++)
        {
            if(j<n-i)
            {
                printf("%d",j+1+i);
            }
            else
            {
                printf("%d",k);
                k--;
            }
        }
        printf("\n");
    }
}
