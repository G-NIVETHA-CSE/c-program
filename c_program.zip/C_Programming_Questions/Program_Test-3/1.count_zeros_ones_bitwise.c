#include<stdio.h>
int main()
{
	int a;
	printf("enter the num in hexa\n");
	scanf("%x",&a);
	int i,ones=0,zeros=0;
	int size=sizeof(int)*8;
	for(i=0;i<size;i++)
	{
		if(a&(1<<i))
		{
			ones++;
		}
		else
		{
			zeros++;
		}
	}
	printf("The ones %d",ones);
       printf("The zeros %d",zeros);	
       return 0;

}

