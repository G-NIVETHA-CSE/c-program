#include<stdio.h>
int main()
{
	char a[20];
	printf("Enter the string\n");
        scanf("%s",a);
	int i;
	for(i=0;a[i]!='\0';i++)
	{
	 if((a[i]>='a') &&(a[i]<='z'))
	{
	 a[i]-=' ';
 	}	
	else if((a[i]>='A') &&(a[i]<='Z'))
        {                 
         a[i]+=' ';
        }
	}
	printf("toggle string %s",a);
}
	

