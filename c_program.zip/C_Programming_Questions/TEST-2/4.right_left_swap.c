//seperate a odd and even number in a array while maintaining the relative order in c 

#include<stdio.h>
#include<stdlib.h>
void rearrange(int arr[],int n)
{
        int j=0,temp;
        for(int i=0;i<n;i++)
        {
                if(arr[i]%2==1)
                {
                        if(i!=j)
                        {
                                temp=arr[i];
                                arr[i]=arr[j];
                                arr[j]=temp;
                        }
                        j++;
                }
        }
}
 
void print(int arr[],int n)
{
        for(int i=0;i<n;i++)
                printf("%d ",arr[i]);
        printf("\n");
}
 
int main()
{
        int arr[]={5,6,1,2,6,4,7};
        int size=sizeof(arr)/sizeof(arr[0]);
        print(arr,size);
        rearrange(arr,size);
        print(arr,size);
}







/*


#include <stdio.h>
int swap(int a[],int n,int start,int end)
{
    int temp=0;
    temp=a[start];
    a[start]=a[end];
    a[end]=temp;

//    return a;
}
int main() {
    int a[7]={1,2,3,4,5,6,7};
    int i,j,n=7,start,end,flag;
    for(i=0;i<n;i++)
    {
        if((a[i]%2)==0)
        {
            flag=1;
            for(j=i;(j<n && flag==1);j++)
            {
                if((a[j]%2)==1)
                {
                    swap(a,n,i,j);
                    flag=0;
                }
            }
         //   i--;
        }
    }
    for(i=0;i<7;i++)
    {
        printf("%d ",a[i]);
    }
    return 0;
}*/
