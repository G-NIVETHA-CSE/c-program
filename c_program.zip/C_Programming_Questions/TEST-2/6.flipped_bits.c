//flipped to convert integer a to b
#include<stdio.h>

int main()
{
    int a,b,i,size,count=0;
    size=sizeof(a)*8;
    printf("enter the hex num of a and b");
    scanf("%x %x",&a,&b);
    for(i=0;i<size;i++)
    {
        if((a&(1<<i))!=(b&(1<<i)))
        {
            count++;
        }
    }
       printf("the flipped to convert integer a to b %d",count);
}

