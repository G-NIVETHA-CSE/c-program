//search for specific element in array
#include<stdio.h>
int main()
{
    int n,i,data;
    printf("enter the range of array\n");
    scanf("%d",&n);
    int a[n];
     printf("enter the elements\n");
    for(i=0;i<n;i++)
    {
        scanf("%d,",&a[i]);
    }
     printf("enter the search data\n");
     scanf("%d,",&data);
     for(i=0;i<n;i++)
     {
      if(a[i]==data)
      {
          printf("the element in position of %d", i);
          return 0;
      }
       
     }
          printf("not found ");
}
s 
