//transpose matrix
#include<stdio.h>
int main()
{
    int row,col,i,j;
    printf("enter the rows and column of array\n");
    scanf("%d %d",&row,&col);
    int a[row][col];
     printf("enter the elements\n");
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
        scanf("%d,",&a[i][j]);
        }
        printf("\n");
    }
    int c[row][col];
     printf("enter the elements\n");
    for(i=0;i<row;i++)
    {
        for(j=0;j<col;j++)
        {
        c[i][j]=a[j][i];
        printf("%d ",c[i][j]);
        }printf("\n");
    }
    
}

