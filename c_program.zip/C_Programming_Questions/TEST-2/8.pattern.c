#include <stdio.h>

int main() {
  int i,j,n=5;
  for(i=0;i<n;i++)
  {
      for(j=i+1;j<=n;j++)
      {
          if((i==0)||(j==i+1))
          {
              printf("%d",j);
          }
          else if(j==n)
          {
              printf("%d",n);
          }
          else
          {
              printf(" ");
          }
      }
      printf("\n");
  }
    return 0;
}
