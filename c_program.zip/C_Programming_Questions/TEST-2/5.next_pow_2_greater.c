#include<stdio.h>
int main()
{
   int num,i=0;
   printf("enter the num");
   scanf("%d",&num);
   while(num)
   {
       if(num<(1<<i))
       {
           printf("%d",(1<<i));
           return 0;
       }
     i++;
   }
}
