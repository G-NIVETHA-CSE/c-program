// Online C compiler to run C program online
#include <stdio.h>
#include <string.h>

void replace(char *a, int start, char *c, int n,int c1) {
    int i, j;
    int k=strlen(a);
    int end=start+c1;
 
    if(c1==n)
    {
        for (i = start, j = 0; c[j] != '\0'; i++, j++) 
        {
            a[i] = c[j];
        }
    } 
    else if(c1>n)
    {
        int t=c1-n;
       for(i=0;i<t;i++)
        {
            for(j=k+t+1;j>start;j--)
            {
            a[j+1]=a[j];
            // printf("%s\n",a);
            }
        }
         for (i = start, j = 0; c[j] != '\0'; i++, j++) 
        {
            a[i] = c[j];
        }
        
    }
    else if(n > c1)
    {
        int t=n-c1;
        //printf("%d",t);
         for (i = start, j = 0; c[j] != '\0'; i++, j++) 
        {
            a[i] = c[j];
        }
       for(i=0;i<t;i++)
        {
            for(j=end+1;j<=k;j++)
            {
                a[j-1]=a[j];
                 
            }
        }
        
        
    }
    
   
}

void substring(char *a, char *b, char *c) {
    int k, count = 0, i;
    int len = strlen(b);
    int c1=strlen(c);
    for (i = 0; a[i] != '\0'; i++) {
        if (a[i] == b[0]) {
            for (k = 0; b[k] != '\0'; k++) {
                if (a[k + i] == b[k]) {
                    count++;
                }
            }
            if (count == len) {
               // printf("The position of the first index of substring: %d\n", i);
                replace(a, i, c, len,c1);
                //i += (len - 1); 
            }
            count = 0;
        }
    }
   // printf("%s\n", a);
}

int main() {
    char a[100] = "hello 999 hello 99 hello";
    char b[] = "hello";
    char c[] = "12345";
    printf("%s\n",a);
    substring(a, b, c);
    printf("%s\n",a);
    return 0;
}

