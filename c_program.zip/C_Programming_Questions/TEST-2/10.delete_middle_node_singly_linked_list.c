#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

typedef struct node node;

node *head = NULL;

void enqueue(node **head, int a) {
    node *newnode = (node *)malloc(sizeof(node));
    newnode->data = a;
    newnode->next = NULL;

    if (*head == NULL) {
        *head = newnode;
    } else {
        node *temp = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newnode;
    }
}

void display(node *head) {
    node *temp = head;
    if (temp == NULL) {
        printf("List is empty\n");
    } else {
        while (temp != NULL) {
            printf("%d ", temp->data);
            temp = temp->next;
        }
        printf("\n");
    }
}

void dequeue(node **head) {
    if (*head == NULL) {
        printf("List is empty\n");
    } else {
        node *temp = *head;
        *head = temp->next;
        free(temp);
    }
}
void deletemid(node **head) {
    if (*head == NULL || (*head)->next == NULL) {
        printf("List is empty or contains only one element. Cannot delete the middle.\n");
        return;
    }

    node *slow = *head;
    node *fast = *head;
    node *prev = NULL;

    while (fast != NULL && fast->next != NULL) {
        fast = fast->next->next;
        prev = slow;
        slow = slow->next;
    }

    prev->next = slow->next;
    free(slow);
}

void rm_dup(node **head)
{
    node *temp,*re;
    temp=*head;
    node *pre;
    while(temp!=NULL)
    {
        pre=temp;
        re=temp->next;
        while(re!=NULL)
        {
            
            
            if(temp->data == re->data)
            {
                pre->next=re->next;
                free(re);
                re=pre->next;
            }
            else{
            pre=re;
            re=re->next;
        }}
        temp=temp->next;
    }
}


int main() {
    enqueue(&head, 5);
    enqueue(&head, 2);
    enqueue(&head, 6);
    enqueue(&head, 3);
    enqueue(&head, 9);
    display(head);
    deletemid(&head);
    display(head);
    return 0;
}

