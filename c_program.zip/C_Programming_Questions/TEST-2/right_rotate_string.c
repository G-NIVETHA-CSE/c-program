// Online C compiler to run C program online
#include <stdio.h>

int main() {
  char a[20];
  printf("enter the string\n");
  scanf("%s",a);
  int i,count=0,p,j;
  char temp;
  for(i=0;a[i]!='\0';i++)
  {
      count++;
  }
  printf("enter the position");
  scanf("%d",&p);
  for(i=0;i<p;i++)
  {
      temp=a[count-1];
      for(j=0;j<count;j++)
      {
          a[count-j-1]=a[count-j-2];
          
      }
      printf("%s\n",a);
      a[0]=temp;
  }
  printf("%s",a);
    return 0;
}
