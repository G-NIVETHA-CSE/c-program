#include<stdio.h>
int main()
{
   char a[20],b;
   printf("enter the string\n");
   scanf("%s",a);
   printf("count no of occurance of specific character\n");
   scanf(" %c",&b);
    int i,count=0;
    for(i=0;a[i]!='\0';i++)
    {
        if(a[i]==b)
        {
            count++;
        }
    }
    printf("no of occurance of character %c is %d",b,count);
}
