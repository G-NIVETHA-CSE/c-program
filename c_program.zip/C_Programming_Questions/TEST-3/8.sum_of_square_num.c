// Online C compiler to run C program online
#include <stdio.h>

int main() {
  int num,b,k,i;
  printf("enter the number\n");
  scanf("%d",&num);
  for(i=1;i<=num/2;i++)
  {
      k=i*i;
      if(k<=num)
      {
          printf("%d ",k);
          b=b+k;
      }
  }
 printf("\nthe sum of perfect square num=%d",b);

    return 0;
}
