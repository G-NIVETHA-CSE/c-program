#include <stdio.h>

int main() {
  int num,b,k,i=0;
  printf("enter the number\n");
  scanf("%d",&num);
  while(num!=0)
  {
      if(num<(1<<i))
      {
          printf("%d",(1<<i));
          num=0;
      }
      i++;
  }
    return 0;
}
