//2.leap_yr_or_not
#include<stdio.h>
int main()
{
   int year;
   printf("enter the year\n");
   scanf("%d",&year);
   if(((year%100)!=0)||((year%400)==0))
   {
       if((year%4)==0)
       {
           printf("this is a leap year");
       }
       else
       {
            printf("this is a not leap year");
       }
   }
   else
   {
     printf("this is a not leap year");  
   }
}
