//converts_char_to_corresponding_ascii value
#include<stdio.h>
int main()
{
  char a;
   printf("enter the char\n");
   scanf("%c",&a);
   int b;
   b=(int)a;
   printf("char to int %d\n",b);
   printf("the character %c\n",(char)b);
}
