//DEVELOP ASCII_code_to_display 
#include<stdio.h>
int main()
{
   int a,count=0;
   printf("enter the ascii code\n");
   scanf("%d",&a);
  if(((a>='a')&&(a<='z'))||((a>='A')&&(a<='Z')))
      count=1;
      
  else if(((a>='0')&&(a<='9')))
   count=2;
   
   else
    count=3;
  switch(count)
  {
      case 1:
        printf("LETTER");
        break;
      
      case 2:
        printf("DIGITS");
        break;
    
     case 3:
        printf("SPECIAL CHARACTER");
        break;
  }
}
