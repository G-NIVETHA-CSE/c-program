#include <stdio.h>

int main() {
  long long int num,b,i=0;
  printf("enter the number");
  scanf("%lld",&num);
  while(num!=0)
  {
      if(num&1)
      {
          b=b+pow(10,i);
      }
      num=num>>1;
      i++;
  }
 printf("%lld",b);

    return 0;
}
