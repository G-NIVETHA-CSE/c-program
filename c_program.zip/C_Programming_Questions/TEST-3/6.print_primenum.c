// Online C compiler to run C program online
#include <stdio.h>

int main() {
  int range,i,j,count=0;
  printf("enter the range");
  scanf("%d",&range);
  printf("enter the prime numbers");
  for(i=1;i<range;i++)
  {
      count=0;
      for(j=1;j<=i/2;j++)
        {
            if((i%j)==0)
            {
                count++;
            }
        }
        if(count==1)
        {
            printf("%d ",i);
        }
  }

    return 0;
}
